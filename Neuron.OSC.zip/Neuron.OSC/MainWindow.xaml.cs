﻿// --------------------------------------------------------------------------------------------------------------------
// <copyright file="MainWindow.xaml.cs" company="Luis Soler">
//   Copyright © 2012-2014
// </copyright>
// <summary>
//   Interaction logic for MainWindow.xaml
// </summary>
// --------------------------------------------------------------------------------------------------------------------

namespace Neuron.OSC
{
    using System;
    using System.Collections.Generic;
    using System.Diagnostics;
    using System.Linq;
    using System.Text;
    using System.Threading.Tasks;
    using System.Windows;
    using System.Windows.Controls;
    using System.Windows.Data;
    using System.Windows.Documents;
    using System.Windows.Input;
    using System.Windows.Media;
    using System.Windows.Media.Imaging;
    using System.Windows.Navigation;
    using System.Windows.Shapes;
    using System.Windows.Threading;

    using Lysis.Commom.BarCode;

    using Neuron.HIS.Models.Common;

    using NeuronCloud.Atpc.Co.Modelos;
    using NeuronCloud.Atpc.Co.Modelos.Auxiliares;
    using NeuronCloud.Atpc.Co.WPF;

    /// <summary>
    /// Interaction logic for MainWindow.xaml
    /// </summary>
    public partial class MainWindow : NeuronMainWindow
    {
        private MainWindowControler controller;

        private bool moveNext;

        public MainWindow()
        {
            this.InitializeComponent();
            this.controller = new MainWindowControler(this, this.ViewModel);
            this.ViewModel.CargarPrefijosOSC<string>(OrigenDatos.DesdeCSV, true, Properties.Settings.Default.PrefijosOsc, valorPorDefecto: Properties.Settings.Default.PrefijoOSCDefault);
            this.ViewModel.MainWindow = this;
            this.ViewModel.TotalModificable = App.TotalModificable;
            this.ViewModel.BuscarServiciosPrevios = App.BuscarServiciosPrevios;
            this.Loaded += (sender, args) =>
                {
                    if (Properties.Settings.Default.MostrarNomSede)
                    {
                        this.Title = $"{this.Title}: {Properties.Settings.Default.NomSede}";
                    }

                    var origin = this.WindowState;
                    this.WindowState = WindowState.Maximized;
                    var max = this.InternalServicesGrid.ActualHeight;
                    this.InternalServicesGrid.MaxHeight = max;
                    this.WindowState = origin;
                    this.VerificarImpresora();
                };
            this.Closing += (sender, args) =>
                {
                    Properties.Settings.Default.PrefijoOSCDefault = this.ViewModel.OscPrefix;
                    if (this.ViewModel.NumeroDeMuestraAsignado != null && this.ViewModel.NumeroDeMuestraAsignado.CentroDeToma != null)
                    {
                        Properties.Settings.Default.PrefijoCentroDeTomaDefault = this.ViewModel.NumeroDeMuestraAsignado.CentroDeToma.Prefijo;
                    }
                };
            this.ViewModel.DiagnosticosCargados += (sender, args) => this.abDiagnostico.PopulateComplete();
            this.ViewModel.PersonalAsistencialEvento += (sender, args) => this.abPersonalAsistencial.PopulateComplete();
        }

        private void AutoCompleteBox_OnSelectionChanged(object sender, SelectionChangedEventArgs e)
        {
            var autoCompleteBox = sender as AutoCompleteBox;

            if (autoCompleteBox != null)
            {
                this.ViewModel.SelectedDiagnose = autoCompleteBox.SelectedItem as Diagnose;
            }
        }

        private void AutoCompleteBox_OnPopulating(object sender, PopulatingEventArgs e)
        {
            var autoCompleteBox = sender as AutoCompleteBox;

            if (autoCompleteBox != null)
            {
                this.ViewModel.SearchDiagnoses(autoCompleteBox.Text);
            }

            e.Cancel = true;
        }

        private void AbPersonalAsistencial_OnPopulating(object sender, PopulatingEventArgs e)
        {
            var autoCompleteBox = sender as AutoCompleteBox;

            if (autoCompleteBox != null)
            {
                this.ViewModel.LoadPersonalAsistencial(new Tuple<string, string>(this.ViewModel.SelectedAgreement.Code, autoCompleteBox.Text));
            }

            e.Cancel = true;
        }

        private void AbPersonalAsistencial_OnSelectionChanged(object sender, SelectionChangedEventArgs e)
        {
            var autoCompleteBox = sender as AutoCompleteBox;

            if (autoCompleteBox != null)
            {
                this.ViewModel.SelectedPersonalAsistencial = autoCompleteBox.SelectedItem as PersonalAsistencial;
            }
        }

        private void TextBox_OnKeyUp(object sender, KeyEventArgs e)
        {
            if (e.Key == Key.Up)
            {
                this.ViewModel.SeleccionarRemitente(Direccion.Arriba);
            }
            else if (e.Key == Key.Down)
            {
                this.ViewModel.SeleccionarRemitente(Direccion.Abajo);
            }
            else if (e.Key == Key.Return || e.Key == Key.Enter)
            {
                this.ListaRemitentesCb.IsDropDownOpen = false;

                var transRequest = new TraversalRequest(FocusNavigationDirection.Next);
                var keyboardFocus = Keyboard.FocusedElement as UIElement;

                if (keyboardFocus != null)
                {
                    keyboardFocus.MoveFocus(transRequest);
                }

                e.Handled = true;
            }
        }

        private void TextBox_OnGotFocus(object sender, RoutedEventArgs e)
        {
            this.ListaRemitentesCb.IsDropDownOpen = true;
            Debug.WriteLine("Abrir Lista");
            e.Handled = true;
        }

        private void TextBox_OnLostFocus(object sender, RoutedEventArgs e)
        {
            this.ListaRemitentesCb.IsDropDownOpen = false;
            Debug.WriteLine("Cerrar Lista");
            this.CmbEditable.Visibility = Visibility.Hidden;
            this.cmbNoEditable.Visibility = Visibility.Visible;
        }

        private void TextBox_OnGotKeyboardFocus(object sender, KeyboardFocusChangedEventArgs e)
        {
            Debug.WriteLine("Get KeyboardFocus");
        }

        private void TextBox_OnGotMouseCapture(object sender, MouseEventArgs e)
        {
            Debug.WriteLine("TextBox_GotMouseCapture");
            Debug.WriteLine(this.ListaRemitentesCb.IsDropDownOpen);

            this.ListaRemitentesCb.IsDropDownOpen = true;

            e.Handled = true;
        }

        private void TextBox_OnLostKeyboardFocus(object sender, KeyboardFocusChangedEventArgs e)
        {
            Debug.WriteLine("TextBox_LostKeyboardFocus");
        }

        private void TextBox_OnLostMouseCapture(object sender, MouseEventArgs e)
        {
            Debug.WriteLine("TextBox_LostMouseCapture");
            Debug.WriteLine(this.ListaRemitentesCb.IsDropDownOpen);
        }

        private void ListaRemitentesCb_OnMouseDown(object sender, MouseButtonEventArgs e)
        {
            Debug.WriteLine("ListaRemitentesCb_MouseDown");
        }

        private void ListaRemitentesCb_OnPreviewMouseDown(object sender, MouseButtonEventArgs e)
        {
            Debug.WriteLine("ListaRemitentesCb_PreviewMouseDown");
        }

        private void _updateModel(object sender, MouseButtonEventArgs e)
        {
            Debug.WriteLine("_updateModel");
            this.moveNext = true;
            e.Handled = true;
        }

        private void ListaRemitentesCb_OnSelectionChanged(object sender, SelectionChangedEventArgs e)
        {
            Debug.WriteLine("ListaRemitentesCb_SelectionChanged");
            if (this.moveNext)
            {
                this.moveNext = false;
                var transRequest = new TraversalRequest(FocusNavigationDirection.Next);
                UIElement keyboardFocus = this.CmbEditable;

                if (keyboardFocus != null)
                {
                    keyboardFocus.MoveFocus(transRequest);
                }
            }
        }

        private void CmbNoEditable_OnGotFocus(object sender, RoutedEventArgs e)
        {
            this.CmbEditable.Visibility = Visibility.Visible;
            this.cmbNoEditable.Visibility = Visibility.Hidden;
            this.Dispatcher.BeginInvoke(DispatcherPriority.Render, new Action(() => this.CmbEditable.Focus()));
        }
      

        ////private void ListaRemitentesCb_OnSourceUpdated(object sender, DataTransferEventArgs e)
        ////{
        ////    var comboBox = sender as ComboBox;

        ////    if (comboBox != null)
        ////    {
        ////        if (comboBox.Items.Count == 1)
        ////        {
        ////            comboBox.Items.MoveCurrentToFirst();
        ////        }
        ////    }
        ////}

        private void VerificarImpresora()
        {
            //if (App.ImprimirCodigosDeBarras)
            {
                if (string.IsNullOrWhiteSpace(App.NombreImpresoraCodigoDeBarras))
                {
                    this.ViewModel.AlertsAndWarningsCollection.Add("Nombre de Impresora No Definido");
                    this.ViewModel.HayAlerta = true;
                    return;
                }

                Utils.PrintLabelAsync(null, App.NombreImpresoraCodigoDeBarras, "Test Lysis: " + DateTime.Now)
                    .ContinueWith(
                        except => Task.Factory.StartNew(
                            () =>
                                {
                                    if (except != null && except.Result != null)
                                    {
                                        this.Dispatcher.Invoke(
                                            new Action(
                                                () =>
                                                    {
                                                        this.ViewModel.AlertsAndWarningsCollection.Add("Error: " + except.Result.Message);
                                                        this.ViewModel.HayAlerta = true;
                                                    }));
                                    }
                                    else
                                    {
                                        this.Dispatcher.Invoke(
                                            new Action(() => this.ViewModel.AlertsAndWarningsCollection.Add("Impresora de Código de Barras en Uso: \"" + App.NombreImpresoraCodigoDeBarras + "\"")));
                                    }
                                }));
            }
        }


	}
}
