﻿namespace Neuron.OSC.Data.Model
{


    partial class OscDataModel
    {
        partial class OSCTipoPagoDataTable
        {
        }
    }
}

namespace Neuron.OSC.Data.Model.OscDataModelTableAdapters
{


    public partial class PRO_OSCDFLiquidaPagoTableAdapter
    {
    }
}
