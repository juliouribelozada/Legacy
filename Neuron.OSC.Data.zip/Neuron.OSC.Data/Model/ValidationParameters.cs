﻿namespace Neuron.OSC.Data.Model
{
    public class ValidationParameters
    {
        public string Password { get; set; }

        public string SpecialityCode { get; set; }

        public string State { get; set; }

        public string UserName { get; set; }
    }
}
