﻿// --------------------------------------------------------------------------------------------------------------------
// <copyright file="ServiceUnitParameters.cs" company="NeuronCloud.co">
//   ATPC © 2012
//   Luis Antonio Soler Barrera
// </copyright>
// <summary>
//   
// </summary>
// --------------------------------------------------------------------------------------------------------------------

namespace Neuron.OSC.Data.Model
{
    public class ServiceUnitParameters
    {
        public string CodigoConvenio { get; set; }

        public string CodigoRemitente { get; set; }
    }
}
