﻿// --------------------------------------------------------------------------------------------------------------------
// <copyright file="OperacionAsincronaEventHandler.cs" company="">
//   TODO: Update copyright text.
// </copyright>
// <summary>
//   
// </summary>
// --------------------------------------------------------------------------------------------------------------------

namespace Neuron.OSC.Data
{
    using System.ComponentModel;

    public delegate void OperacionAsincronaEventHandler(object sender, RunWorkerCompletedEventArgs e);
}
